There are two bins for ESP8266_Adaptivity_v2.1. The difference shows up in the postfix where 1M & 2M represent the bin size.
